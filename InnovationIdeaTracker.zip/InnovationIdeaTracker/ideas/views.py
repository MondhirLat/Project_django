
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from .models import Idea, Comment

def idea_list(request):
    ideas = Idea.objects.all()
    return render(request, 'ideas/idea_list.html', {'ideas': ideas})

def idea_detail(request, pk):
    idea = get_object_or_404(Idea, pk=pk)
    return render(request, 'ideas/idea_detail.html', {'idea': idea})
